#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int main()
{
	// To create pointer for the file
	FILE* NameOfFile;

	//FOPEN
	NameOfFile = fopen("name.txt", "mode(w,r)"); // Opens file (name.txt) in specific mode
	if (NameOfFile == NULL)
	{
		// What to do if file didn't open
	}
	/* MODE OPTIONS
		r - Read Only
		w - Write (Will erase previous file if already existed)
		a - Append info to already existing file
		r+ - Read + Write
		w+ - Write + Read (Will erase previous file if already existed)

		// NOT SAFE TO USE
		a+ - Append + Read
	*/

	//FCLOSE
	fclose(NameOfFile); // Will close and save file (Also free some memory)
	
	//				IMPORTANT!!!
	// no need to use fclose() if we use exit()

	//FSCANF
	int num;
	fscanf(NameOfFile, "%d", &num); // Reads info from file and puts it in num
	// If instead of NameOfFile insert stdin will work exactly like scanf

	// NOTE
	// Will return fscanf = -1 at the end of file (basically means end of file)

	//FPRINTF
	int input;
	fprintf(NameOfFile, "%TypeOfFile", input); // Prints input inside the file

	//FTELL
	ftell(NameOfFile); // Returns the position of pointer atm

	// ATOI ATOF ATOL
	int num1 = atoi(NameOfString); // transfers from ASCII -> Integer
	float num2 = atof(NameOfString); // Transfers from ASCII -> Float
	double num2 = atol(NameOfString); // Transfers from ASCII -> double or longfloat

	// 
	while(fscanf() != EOF);
	while(fgets()!=NULL);

	// if there is a space between values use ex(1 2 3 4 5) use -> SCANF
	// if there are in a row without spaces ex(123567) use -> FGETS 
}

